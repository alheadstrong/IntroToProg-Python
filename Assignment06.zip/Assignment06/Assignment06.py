#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   AFilson, 05/06/2017, Added code to complete assignment 5
#   AFilson, 05/13/2017, Created Functions and Class for assignment 6
#https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# strChoice = Capture the user option selection

objFileName = "C:\_PythonClass\ToDo.txt"
strData = ""
dicRow = {}
strChoice = ""

#-- Processing --#

class BasicOperations(object):

    # Prints items from a dictionary to rows
    @staticmethod
    def PrintDic(dic):
        for key,value in dic.items():
            print("{}, {}\n".format(key,value))

    # opens file and reads comma separated string rows to key and
    # value of a dictionary
    @staticmethod
    def ReadTxtDic(file,dic):
        objFile = open(file, "r")
        for line in objFile:
            strData = line.strip().split(',')
            dic.update({strData[0]: strData[1]})
        return dic

    # removes an item from a dictionary or returns error
    @staticmethod
    def DeleteDicItem(dic,key):
        if key in dic:
            del dic[key]
            print("\n", key, " deleted")
        else:
            print(key, " does not exist")
        return dic

    # writes current dictionary to text file as rows of strings,
    # saves and closes file
    @staticmethod
    def WriteDicTxt(dic,file):
        objFile = open(file, 'w')
        for key, value in dic.items():
            objFile.write("{},{}\n".format(key, value))
        objFile.close()

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# Step 1
    # When the program starts, load the any data you have
    # in a text file called ToDo.txt into a python Dictionary.

BasicOperations.ReadTxtDic(objFileName,dicRow)

# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()# adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print("Current data: ","\n")
        BasicOperations.PrintDic(dicRow)
        continue
    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        strTask = input("Enter name of new task: ")
        strPriority = input("Enter name of task priority: ")
        dicRow.update({strTask: strPriority})
        print("Current data: ", "\n")
        BasicOperations.PrintDic(dicRow)
        continue
    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        strTask = input("Which task would you like to remove?")
        BasicOperations.DeleteDicItem(dicRow,strTask)
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        BasicOperations.WriteDicTxt(dicRow,objFileName)
        continue
    elif (strChoice == '5'):
        break # and Exit the program


